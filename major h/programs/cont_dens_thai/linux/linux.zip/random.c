
#define SIZE 1000 
*Y()
{
int i,j;
int X[SIZE][90];
int *a1;
for(i=0;i<SIZE;i++)
for(j=0;j<90;j++)


if(rand()>RAND_MAX/2)
X[i][j]=1;
else
X[i][j]=0;

return &X[0][0];
}


